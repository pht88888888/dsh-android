# Page Brief Template & Parallel Execution Contract

> 供 Step 5 fan-out 使用。父代理按本文件为每页产出 `<project>/briefs/P<NN>.md`，并按「子代理 prompt 模板」派发。
> 本文件是作者指南 + 运行时模板——产出文件本身不要带本节说明文字（同 spec_lock 纪律：只留数据行）。

## 1. 并行纪律（父代理铁律）

- **并发上限 5**。页数 N > 5 时 5 个子代理均匀分页；≤5 时每子代理 1 页。不要因"更快"突破 5——手机引擎与 LLM 并发压力有上限。
- **spec_lock 冻结**：T0 校验终态后，整个生成期不得修改。中途补色/补字号 = 已画页全部漂移。发现缺口 → 停下把缺口并入 brief（该页特殊处理），不要全局改锁。
- **T0 清空依赖**：所有不依赖子代理产物的工作（brief、spec 校验、notes 归位、图标同步）必须在 spawn 前完成。
- **T1 放手**：派发后不揽任何活，不轮询。结束回合等 notice。
- **T2 只验收与修复**：通知驱动逐份预验收；fail 页 send_message 续修或重派，不整卷重画。

## 2. 每页 brief 文件结构（`<project>/briefs/P<NN>.md`）

```markdown
# P<NN> brief
- file: <NN>_<page_name>.svg
- rhythm: <anchor|dense|breathing>
- layout_template: <basename 或 none>        # 对应 spec_lock.page_layouts
- chart_template: <basename 或 none>          # 对应 spec_lock.page_charts
- icons: <icon1>, <icon2>                     # 本页用到的图标名（inventory 内）
- images: <images/xxx.png 或 none>            # 本页引用的图片文件（必须是 spec_lock.images 内）

## 内容（§IX 本页原文，逐字保留）
<该页全部内容块；prose 保留整段，勿改列表/分段>

## 布局要点
<可选：本页信息层级/区块排布建议，来自 design_spec 的页面叙述>
```

## 3. 子代理 prompt 模板（自足，子代理看不到父会话）

```text
你是 PPT 单页执行员。项目根目录：<project 绝对路径>。
只做一件事：为下面列出的每一页手写一个自包含 SVG 文件到 <project>/svg_output/，然后自查。

【执行前必读（按序）】
1. read <project>/spec_lock.md —— 颜色/字号/字体/图标/图片只准用它，禁止发明任何值；
2. read <project>/briefs/P<NN>.md（每页一份）—— 本页内容与要求；
3. read <project>/notes/<NN>_*.md（若存在）—— 补充内容；
4. 若 brief 的 layout_template 非 none：read <project>/templates/<basename>.svg 继承其几何结构（只继承结构，fill/stroke/字号一律按 spec_lock 重排）；
   若 brief 的 chart_template 非 none：read <project>/templates/charts/<chart_name>.svg 同理。

【硬性规范】
- 画布 1280×720（或 spec_lock.canvas 值），viewBox 与 width/height 一致，background 用 <rect>；
- 颜色全部来自 spec_lock.colors；字号写 spec_lock.typography 的角色值（禁沿用模板 14px 之类占位字号）；
- 禁止: rgba()、<style>/class、<foreignObject>、mask、textPath、@font-face、动画、<script>、<symbol>+<use>、group opacity、HTML named entities（&mdash; &copy; 等）——文本符号写 raw Unicode（— © →），XML 保留字转义（&lt; &amp;）；
- 渐变/阴影只在 spec_lock 风格要求且你按 spec 色自绘时允许；禁止原样复制模板里的 <linearGradient>/url(#...);
- 图标用 <use data-icon="<library>/<name>" ...>（若 brief 给了图标名）或内联 path，禁止嵌入整个图标库；
- 图片用 <image href="../images/xxx.png" preserveAspectRatio="xMidYMid slice"/>，只引用 brief.images 列出的文件；
- 文本行高按字号×1.4~1.6 排，CJK 每行约 width÷字号 个字；prose 块不拆成 bullet。

【输出规范】
- 每页写成一个文件：<project>/svg_output/<NN>_<page_name>.svg（文件名以 brief.file 为准）；
- 不要动 svg_output/ 里别人的文件；不要运行 finalize/export/checker 脚本（父代理统一做）。

【自查（写完后，每页都做）】
grep 自己刚写的文件：确认无 spec_lock 之外的颜色 hex、无 banned 特征、字号都是 spec_lock 值。

【回报】一行状态：P<NN> PASS —— 或 —— P<NN> FAIL: <具体原因>（不要长篇，父代理只需知道哪页有问题）。
```

## 4. 分页规则（子代理领页）

N ≤ 5：第 k 个子代理领 P<k>。
N > 5：页号均匀切 5 份，且把同 layout_template 的页尽量打散到不同子代理（避免 5 页都抄同一模板时风格趋同）。相邻页码（封面/目录/结束锚点页）可同组，因其同属 anchor 节奏。

## 5. 收尾判定

- 全部 PASS → 父代理全量跑一次 `svg_quality_checker.py` 复核（子代理自查可能有盲区）；
- 有 FAIL → 只处理 FAIL 页（send_message 原子代理续修 / 重派单页），PASS 页绝不重画；
- warning 尽力修，修不了记录放行（同 SKILL.md Step 6）。
