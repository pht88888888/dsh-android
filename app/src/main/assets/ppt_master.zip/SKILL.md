---
name: ppt-master
description: 制作高质量 PPT 演示文稿。用户给文字需求，AI 严格走多阶段流程（源→提纲→确认→逐页SVG→质检→导出PPTX）。触发词：做PPT、制作演示文稿、生成幻灯片、帮我做个PPT。
---

# Boo 手机端 PPT Master

> 用户用文字描述想要的效果，你严格按本流程制作一份高质量 PPT 并导出为 PPTX。

## ⚠️ 铁律（违反任一 = 失败）

1. **串行执行** — 严格按 Step 顺序，前一步输出是下一步输入。非阻塞步骤可在前置满足后连续推进，无需等用户说"继续"。
2. **⛔ BLOCKING 硬停** — 标记 ⛔ 的步骤必须完整停下，等用户明确回应后才继续，绝不替用户做决定。
3. **禁止跨阶段打包** — 不允许把多个阶段塞在一起做。
4. **门禁先行** — 每个 Step 顶部有 🚧 GATE，必须先核实才能开始。
5. **禁止预演** — 不在 Strategist 阶段预写后续步骤内容（如 Step6 才写 SVG）。
6. **页面并行 fan-out（Step 5 核心）** — SVG 页面相互独立（同 spec_lock 不同内容），必须并行生成以压缩墙钟时间。并发上限 **5 个子代理**：页数 ≤5 时每子代理 1 页；页数 >5 时 5 个子代理 × 每代理连续画 ceil(N/5) 页。并行协议、父代理职责与任务包模板见 `${DATA_DIR}/skills/ppt-master/references/page-brief-template.md`。禁止把多个页面塞进一次批处理脚本（铁律 8 仍生效）。
7. **SPEC_LOCK 唯一取值源** — 颜色/字体/图标/图片只能来自 `<project>/spec_lock.md`，禁止从记忆或现场发明。串行模式下每页前重读一次；并行模式下由各子代理 T0 读一次后画完自己全部页（父代理负责 T0 终态校验，见 Step 5）。
8. **SVG 必须手写** — 每个 SVG 页面由你直接写，禁止写 Python/Node/shell 脚本批量生成 SVG。
9. **路径统一** — skill 根目录为 `${DATA_DIR}/skills/ppt-master/`，脚本/模板/references 均在其中。所有 `SKILL_DIR` 引用替换为 `${DATA_DIR}/skills/ppt-master/`。

## 环境准备（Step 0：首次制作时）

🚧 GATE：`python3 --version` 与 `python3 -c "import pptx"` 需成功。任一失败则按序执行：

**① 装 python + lxml + pillow（走 bridge 的 pkg 拦截，必须作为 bash 工具的顶层命令）：**

```bash
pkg install -y python python-lxml python-pillow
```

> ⚠️ **必须**用 bash 工具直接跑这条 `pkg` 命令。当前 Android 壳会把顶层 `pkg` 请求转发到 Android 原生包服务，正确解包到 app 私有目录。**不要**把 pkg 写进脚本文件再执行，也**不要**在 pkg 失败后改用 pip 安装 lxml 或 Pillow；失败必须停下并报告原始错误。lxml/pillow 单独用 pkg 装是 Android 兼容的预编译包，避免 pip 现场编译失败。安装可能 1-3 分钟，期间用 bash 工具等待输出，完成后继续。

**② 装 pip 依赖（python 装好后）：**

```bash
bash ${DATA_DIR}/skills/ppt-master/scripts/setup_ppt_env.sh
```

脚本装 python-pptx + svglib + reportlab（pillow 已由 pkg 装好，勿用 pip 再装）。⚠️ 依赖装一次即可，后续直接跳过此步。

## 输入

用户可能只给一句主题（如"我想要一个科技感的产品发布PPT"），或给一份文字提纲。若有源文档（md/txt）可读入。**只有文字需求，无图片**。

## Step 1: 提纲与确认

🚧 GATE：已理解用户需求。

先向用户给出 **PPT 提纲**（标题 + 大致页数 + 各页要点）。然后 ⛔ **等待用户确认或修改**。提纲确认后不再反复问。

## Step 2: 八项确认（两轮 ask 对话框）

🚧 GATE：提纲已确认。

用 **ask 工具** 分两轮确认设计参数。每轮一次 ask 调用，一次拿全部选项：

- **第一轮（anchors）**：画布格式（ppt169 / ppt43 / 竖版）、目标受众、视觉风格（科技/简洁/商务/极简/学术）、核心信息。
- **第二轮（realization）**：页数范围、配色方案、图标用法、字体方案、是否需要公式渲染。

⛔ **每一轮都是 BLOCKING**：ask 返回前不得继续。ask 结果通过 `AnswerQuestion` 拿到后，两轮值合并为最终设计参数。

## Step 3: 初始化项目

🚧 GATE：八项确认完成。

```bash
mkdir -p ${DATA_DIR}/workspace/ppt_projects/
cd ${DATA_DIR}/workspace/ppt_projects/
python3 ${DATA_DIR}/skills/ppt-master/scripts/project_manager.py init <project_name> --format <ppt169|ppt43|xhs|story>
```

project_name 用短横线命名（如 `product_launch`）。源文字需求写入 `sources/input.md`。

## Step 4: 设计规格

🚧 GATE：项目已初始化。

1. 读取 `${DATA_DIR}/skills/ppt-master/references/strategist.md` 了解 Strategist 职责。
2. 生成 `<project>/design_spec.md`（人类可读设计叙述）和 `<project>/spec_lock.md`（机器执行契约），严格按 `${DATA_DIR}/skills/ppt-master/templates/design_spec_reference.md` 和 `spec_lock_reference.md` 结构。**模板在 skill 目录，不是项目里**。
3. 颜色/字体/图标/页面节奏/布局/图表全部写进 spec_lock.md。图表用 SVG 手绘（柱状/折线/饼图/流程/时间线等），**不用图片**。

## Step 5: 并行生成全部 SVG（核心）

🚧 GATE：design_spec + spec_lock 就绪；spec_lock 为**终态**（本步开始后禁止再改，缺色缺字号会分裂 20 页——参考质检脚本 spec_lock drift 检查）。

**本步默认走「父代理编排 + 子代理并行」fan-out（铁律 6）。** 页数少（≤5 页）时可用同一协议但每子代理 1 页。开始前先读 `${DATA_DIR}/skills/ppt-master/references/page-brief-template.md` 与 `executor-base.md`、`shared-standards.md`（规范以这几个文件为准，子代理同样只认它们）。

### T0 · 派发前准备（父代理全部重活，必须做完才 spawn）

1. 为**每一页**写一份 page brief：`<project>/briefs/P<NN>.md`——含本页页码/文件名、§IX 内容要点、page_rhythm 标签、page_layouts/page_charts 指向的模板与图表名、图标清单。严格按 page-brief-template.md 的结构。
2. 校验 spec_lock 完整：跑一次 `svg_quality_checker.py` 的 spec 检查或自查 `colors/typography/icons/page_*/` 全齐、无待补项。
3. 把本页要继承的模板 SVG 路径、notes 内容按页归位（`total_md_split.py` 可拆 notes/<NN>_*.md）。
4. 分组：页数 N，子代理数 = min(5, N)，第 k 个子代理领页号集合（均匀切分，页序打散避免同一模板扎堆）。

### T1 · 派发（同一回合连发，然后放手）

5. 用 **subagent 工具后台并发派发**（默认后台，立即返回 subagentId，不要 run_in_background:false 逐个干等）。每个子代理一个自包含 prompt（见 page-brief-template.md 的 prompt 模板）：告诉它项目绝对路径、自己领的页号集合、每页要读的 brief/notes 路径、产物文件名规范、自查清单。子代理**看不到本会话**，prompt 必须自足。
6. 发完即结束回合：不要继续做任何依赖子代理产物的事（预跑导出/检查 SVG 存在性都是错误）。等待引擎 notice。

### T2 · 通知驱动收尾（父代理验收，不重画）

7. 每个子代理完成 → 引擎 notice 唤醒 → 立即对其产物跑 `python3 ${DATA_DIR}/skills/ppt-master/scripts/svg_quality_checker.py <project_path>`（或单文件模式）预验收。全部收齐后做一次全量质检。
8. 仅对 error/warn 页修复：小问题父代理直接 edit/sed；大问题用 `send_message` 让原子代理续修（它在自己上下文里保留那几页的 spec 记忆），或重派新子代理只修该页。
9. 质检全绿后写演讲者备注 `<project>/notes/total.md`（可在 T0 先写骨架，T2 按最终页补全）。

## Step 6: 质检

🚧 GATE：所有 SVG 生成完。

```bash
python3 ${DATA_DIR}/skills/ppt-master/scripts/svg_quality_checker.py <project_path>
```

任何 error 必须先修复再继续（回 Step 5 重生成该页，重跑检查）。warning 尽量修，修不了记录放行。

## Step 7: 导出 PPTX

🚧 GATE：质检通过（0 errors）。

逐个运行（禁止合并成一条命令）：

```bash
python3 ${DATA_DIR}/skills/ppt-master/scripts/total_md_split.py <project_path>
python3 ${DATA_DIR}/skills/ppt-master/scripts/finalize_svg.py <project_path>
python3 ${DATA_DIR}/skills/ppt-master/scripts/svg_to_pptx.py <project_path>
```

导出文件在 `<project_path>/exports/*.pptx`。

## Step 8: 交付

🚧 GATE：PPTX 已生成。

告知用户 PPTX 完整路径，建议复制到 workspace 根目录方便通过文件分享发送。**不直接操作系统分享**（app 内用户会自己点）。

## 输出语言
与用户输入语言一致。模板字段名（design_spec.md 的结构）保持英文，内容值用用户语言。
