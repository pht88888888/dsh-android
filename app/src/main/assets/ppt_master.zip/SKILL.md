---
name: ppt-master
description: 制作高质量 PPT 演示文稿。用户给文字需求，AI 严格走多阶段流程（源→提纲→确认→逐页SVG→质检→导出PPTX）。触发词：做PPT、制作演示文稿、生成幻灯片、帮我做个PPT。
---

# Boo 手机端 PPT Master

> 用户用文字描述想要的效果，你严格按本流程制作一份高质量 PPT 并导出为 PPTX。

## ⚠️ 铁律（违反任一 = 失败）

1. **串行执行** — 严格按 Step 顺序，前一步输出是下一步输入。非阻塞步骤可在前置满足后连续推进，无需等用户说"继续"。
2. **⛔ BLOCKING 硬停** — 标记 ⛔ 的步骤必须完整停下，等用户明确回应后才继续，绝不替用户做决定。
3. **禁止跨阶段打包** — 不允许把多个阶段塞在一起做。
4. **门禁先行** — 每个 Step 顶部有 🚧 GATE，必须先核实才能开始。
5. **禁止预演** — 不在 Strategist 阶段预写后续步骤内容（如 Step6 才写 SVG）。
6. **逐页顺序生成** — Step 6 中 SVG 页面必须一页一页连续生成，禁止分页批处理（如每 5 页一组）。
7. **SPEC_LOCK 每页重读** — 每页 SVG 前重读 `<project>/spec_lock.md`，颜色/字体/图标/图片只能用它，禁止从记忆或现场发明。
8. **SVG 必须手写** — 每个 SVG 页面由你直接写，禁止写 Python/Node/shell 脚本批量生成 SVG。
9. **路径统一** — skill 根目录为 `${DATA_DIR}/skills/ppt-master/`，脚本/模板/references 均在其中。所有 `SKILL_DIR` 引用替换为 `${DATA_DIR}/skills/ppt-master/`。

## 环境准备（Step 0：首次制作时）

🚧 GATE：`python3 --version` 与 `python3 -c "import pptx"` 需成功。任一失败则按序执行：

**① 装 python + lxml + pillow（走 bridge 的 pkg 拦截，必须作为 bash 工具的顶层命令）：**

```bash
pkg install -y python python-lxml python-pillow
```

> ⚠️ **必须**用 bash 工具直接跑这条 `pkg` 命令。当前 Android 壳会把顶层 `pkg` 请求转发到 Android 原生包服务，正确解包到 app 私有目录。**不要**把 pkg 写进脚本文件再执行，也**不要**在 pkg 失败后改用 pip 安装 lxml 或 Pillow；失败必须停下并报告原始错误。lxml/pillow 单独用 pkg 装是 Android 兼容的预编译包，避免 pip 现场编译失败。安装可能 1-3 分钟，期间用 bash 工具等待输出，完成后继续。

**② 装 pip 依赖（python 装好后）：**

```bash
bash ${DATA_DIR}/skills/ppt-master/scripts/setup_ppt_env.sh
```

脚本装 python-pptx + svglib + reportlab（pillow 已由 pkg 装好，勿用 pip 再装）。⚠️ 依赖装一次即可，后续直接跳过此步。

## 输入

用户可能只给一句主题（如"我想要一个科技感的产品发布PPT"），或给一份文字提纲。若有源文档（md/txt）可读入。**只有文字需求，无图片**。

## Step 1: 提纲与确认

🚧 GATE：已理解用户需求。

先向用户给出 **PPT 提纲**（标题 + 大致页数 + 各页要点）。然后 ⛔ **等待用户确认或修改**。提纲确认后不再反复问。

## Step 2: 八项确认（两轮 ask 对话框）

🚧 GATE：提纲已确认。

用 **ask 工具** 分两轮确认设计参数。每轮一次 ask 调用，一次拿全部选项：

- **第一轮（anchors）**：画布格式（ppt169 / ppt43 / 竖版）、目标受众、视觉风格（科技/简洁/商务/极简/学术）、核心信息。
- **第二轮（realization）**：页数范围、配色方案、图标用法、字体方案、是否需要公式渲染。

⛔ **每一轮都是 BLOCKING**：ask 返回前不得继续。ask 结果通过 `AnswerQuestion` 拿到后，两轮值合并为最终设计参数。

## Step 3: 初始化项目

🚧 GATE：八项确认完成。

```bash
mkdir -p ${DATA_DIR}/workspace/ppt_projects/
cd ${DATA_DIR}/workspace/ppt_projects/
python3 ${DATA_DIR}/skills/ppt-master/scripts/project_manager.py init <project_name> --format <ppt169|ppt43|xhs|story>
```

project_name 用短横线命名（如 `product_launch`）。源文字需求写入 `sources/input.md`。

## Step 4: 设计规格

🚧 GATE：项目已初始化。

1. 读取 `${DATA_DIR}/skills/ppt-master/references/strategist.md` 了解 Strategist 职责。
2. 生成 `<project>/design_spec.md`（人类可读设计叙述）和 `<project>/spec_lock.md`（机器执行契约），严格按 `${DATA_DIR}/skills/ppt-master/templates/design_spec_reference.md` 和 `spec_lock_reference.md` 结构。**模板在 skill 目录，不是项目里**。
3. 颜色/字体/图标/页面节奏/布局/图表全部写进 spec_lock.md。图表用 SVG 手绘（柱状/折线/饼图/流程/时间线等），**不用图片**。

## Step 5: 逐页生成 SVG（核心）

🚧 GATE：design_spec + spec_lock 就绪。

1. 读取 `${DATA_DIR}/skills/ppt-master/references/executor-base.md` 和 `shared-standards.md`。
2. **每页开始前重读 `<project>/spec_lock.md`**，只用它里的颜色/字体/图标/图片。查该页 `page_rhythm`（anchor/dense/breathing）、`page_layouts`（继承哪个模板 SVG）、`page_charts`（哪个图表模板）。
3. 图标从 `${DATA_DIR}/skills/ppt-master/templates/icons/tabler-outline/` 选（`ls | grep 关键字`），读 SVG 后用其 path 绘制，不要全量嵌入。
4. **逐页手写 SVG** 到 `<project>/svg_output/`，一页一页连续完成。每页 16:9（或确认的画布），尺寸统一。SVG 必须自包含（字体用系统常见字体，颜色用 spec_lock 值，图标内联 path）。
5. 生成演讲者备注到 `<project>/notes/total.md`。

## Step 6: 质检

🚧 GATE：所有 SVG 生成完。

```bash
python3 ${DATA_DIR}/skills/ppt-master/scripts/svg_quality_checker.py <project_path>
```

任何 error 必须先修复再继续（回 Step 5 重生成该页，重跑检查）。warning 尽量修，修不了记录放行。

## Step 7: 导出 PPTX

🚧 GATE：质检通过（0 errors）。

逐个运行（禁止合并成一条命令）：

```bash
python3 ${DATA_DIR}/skills/ppt-master/scripts/total_md_split.py <project_path>
python3 ${DATA_DIR}/skills/ppt-master/scripts/finalize_svg.py <project_path>
python3 ${DATA_DIR}/skills/ppt-master/scripts/svg_to_pptx.py <project_path>
```

导出文件在 `<project_path>/exports/*.pptx`。

## Step 8: 交付

🚧 GATE：PPTX 已生成。

告知用户 PPTX 完整路径，建议复制到 workspace 根目录方便通过文件分享发送。**不直接操作系统分享**（app 内用户会自己点）。

## 输出语言
与用户输入语言一致。模板字段名（design_spec.md 的结构）保持英文，内容值用用户语言。
